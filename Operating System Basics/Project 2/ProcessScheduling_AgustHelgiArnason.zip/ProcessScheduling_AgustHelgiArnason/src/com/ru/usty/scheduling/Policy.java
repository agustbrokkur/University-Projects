package com.ru.usty.scheduling;

/**
 * 
 * DO NOT CHANGE THIS ENUM
 *
 */

public enum Policy {
	FCFS,
	RR,
	SPN,
	SRT,
	HRRN,
	FB
}
