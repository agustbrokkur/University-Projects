﻿using System;
using System.Collections.Generic;
using Manifesto.Models.Entities;
using Manifesto.Models.InputModels;
using Manifesto.Repositories;
namespace Manifesto.Services
{
    public class BookService
    {
		private BookRepository repository;

        public BookService()
        {
			repository = new BookRepository();
        }

		public void UpdateBookById(Guid id, BookInputModel newVersionOfBook)
        {
			repository.UpdateBookById(id, newVersionOfBook);
        }

        public void DeleteBookById(Guid id)
        {
			repository.DeleteBookById(id);
        }

        public IEnumerable<Book> GetAllBooks()
        {
			return repository.GetAllBooks();
        }

        public void CreateBook(BookInputModel bookToCreate)
        {
			repository.CreateBook(bookToCreate);
        }

        public BookInputModel GetBookById(Guid id)
        {
			return GetBookById(id);
        }


    }
}
