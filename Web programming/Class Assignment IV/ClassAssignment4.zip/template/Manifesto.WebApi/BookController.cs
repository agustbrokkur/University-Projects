﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Manifesto.Services;
using Manifesto.Models.InputModels;
using Manifesto.Models.Entities;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Manifesto.WebApi
{
    public class BookController : Controller
    {

		private BookService service;

		public BookController() {
			service = new BookService();
		}

        public IActionResult Index()
        {
            return View();
        }

		[HttpGet("{category}")]
		public IActionResult GetAllBooks(string category)
        {
			return Ok(service.GetAllBooks().Where<Book>((book) => book.Category == category));
        }

		[HttpPost("{CreateBook}")]
		public IActionResult CreateBook(BookInputModel bookToCreate)
        {
			service.CreateBook(bookToCreate);
			return Ok("Book created.");
        }

		public IActionResult UpdateBookById(Guid id, BookInputModel newVersionOfBook)
        {
			service.UpdateBookById(id, newVersionOfBook);
			return Ok("Book has been updated.");
        }

		public IActionResult DeleteBookById(Guid id)
        {
			service.DeleteBookById(id);
			return Ok("Book has been deleted.");
        }

        public IActionResult GetBookById(Guid id)
        {
			return Ok(service.GetBookById(id));
        }
    }
}
