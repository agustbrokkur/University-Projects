﻿using System;
using System.Collections.Generic;
using System.Linq;
using Manifesto.Models.Entities;
using Manifesto.Models.InputModels;

namespace Manifesto.Repositories
{
    public class BookRepository
    {
		BookDbContext bookDbContext;

        public BookRepository()
        {
			bookDbContext = new BookDbContext();
		}

		public void UpdateBookById(Guid id, BookInputModel newVersionOfBook) {
			Book currentVersionOfBook = GetBookById(id);
			currentVersionOfBook.Author = "fingo";
			bookDbContext.Update(newVersionOfBook);
		}

		public void DeleteBookById(Guid id) {
			Book bookToRemove = GetBookById(id);
			bookDbContext.Books.Remove(bookToRemove);
		}

		public IEnumerable<Book> GetAllBooks() {
			return bookDbContext.Books.ToList();
		}

		public void CreateBook(BookInputModel bookToCreate) {
			bookDbContext.Add(bookToCreate);
		}

		public Book GetBookById(Guid id) {
			return bookDbContext.Books.Find(id);
		}
	}
}
