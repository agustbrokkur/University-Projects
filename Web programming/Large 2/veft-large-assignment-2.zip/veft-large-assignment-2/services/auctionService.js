const EventEmitter = require('events');
const { Auction, AuctionBid, Customer, Art} = require("../data/db");

class AuctionService extends EventEmitter {
	constructor() {
		super();
		this.events = {
			GET_ALL_AUCTIONS: 'GET_ALL_AUCTIONS',
			GET_AUCTION_BY_ID: 'GET_AUCTION_BY_ID',
			GET_AUCTION_WINNER: 'GET_AUCTION_WINNER',
			CREATE_AUCTION: 'CREATE_AUCTION',
			GET_AUCTION_BIDS_WITHIN_AUCTION: 'GET_AUCTION_BIDS_WITHIN_AUCTION',
			PLACE_NEW_BID: 'PLACE_NEW_BID'
		};
	}

	getAllAuctions() {
	    Auction.find({}, (err, auctions) => {
	        if (err) {
	        	this.emit('error', { statusCode: 500, message: err });
	        } else if(!auctions) {
                this.emit('error', {statusCode: 404, message: 'Not found'});
	        } else {
	            this.emit(this.events.GET_ALL_AUCTIONS, auctions);
	        }
	    });
	};

	getAuctionById(id) {
		// Your implementation goes here
    // Should emit a GET_AUCTION_BY_ID event when the data is available
		Auction.findById(id, (err, auction) => {
			if (err) {
	        	this.emit('error', { statusCode: 500, message: err });
			} else if(!auction) {
                this.emit('error', {statusCode: 404, message: 'Not found'});
			} else {
				this.emit(this.events.GET_AUCTION_BY_ID, auction);
			}
		});
	};

	getAuctionWinner(auctionId) {
		Auction.findById( auctionId, (err, auction) => {
			if (err) {
				this.emit('error', { statusCode: 500, message: err });
			} else if(!auction) {
        		this.emit('error', {statusCode: 404, message: 'Not found'});
			} else if(auction.endDate > Date.now) {
				this.emit('error', { statusCode: 409, message: err });
			} else if(auction.auctionWinner === null) {
				this.emit('no bids', { statusCode: 200, message: "This auction had no bids." });
			} else {
				this.emit(this.events.GET_AUCTION_WINNER, auction);
			}
		});
	};

	createAuction(auction) {
		// Your implementation goes here
		// Should emit a CREATE_AUCTION event when the data is available
		Auction.create(auction, (err, newAuction) => {
			if(err) {
				this.emit('error', {statusCode: 500, message: err});
			} else if(!newAuction) {
        		this.emit('error', {statusCode: 404, message: 'Not found'});
			} else {
				Art.findById(newAuction.artId, (err, art) => {
					if(!art){
						this.emit('error', {statusCode: 400, message: 'Art Not Found'});
					}
					else if (!art.isAuctionItem) {
						this.emit('error', {statusCode: 412, message: 'Item is not an auction item'});
					}
					else{
						this.emit(this.events.CREATE_AUCTION, newAuction);
					}
				});
			}
		});
	};

	getAuctionBidsWithinAuction(auctionId) {
		Auction.findById(auctionId, (err, auction) => {
			AuctionBid.find({"auctionId": auctionId}, (err, auctionBids) => {
				if (err) {
					this.emit('error', { statusCode: 500, message: err });
				} else if(!auctionBids) {
        			this.emit('error', {statusCode: 404, message: 'Not found'});
				} else {
					this.emit(this.events.GET_AUCTION_BIDS_WITHIN_AUCTION, auctionBids);
				}
			});
		});
	};

	placeNewBid(auctionId, customerId, price) {
		// Your implementation goes here
		// Should emit a PLACE_NEW_BID event when the data is available
			//Auction bids must be higher than the minimum price and must also be higher than the current highest bid.
			//If the auction bid price is lower than the minimum price or current highest bid,
			//the web service should return a status code 412 (Precondition failed).
			//If the auction has already passed its end date, the web service should return a status code 403 (Forbidden).
			//As a side-eﬀect the auctionWinner property in the Auction schema should be updated to the latest highest bidder.
		const context = this;
		Auction.findById(auctionId, (err, auction) => {
			if(err) {
				this.emit('error', {statusCode: 500, message: err});
			}
			else if(!auction){
				this.emit('error', {statusCode: 404, message: 'Auction not found'});
			}
			else if(auction.minimumPrice > price) {
				this.emit('error', {statusCode: 412, message: 'Bid too low'});
			} else {
				AuctionBid.find({"auctionId": auctionId}).sort('-price').limit(1).exec(function (err, highestBid) {
					if(err) {
						context.emit('error', {statusCode: 500, message: err});
					} else if (!highestBid){
						context.emit('error', {statusCode: 404, message: 'Auction not found'});
					} else if ((highestBid[0] !== undefined) && (highestBid[0].price >= price)) {
						context.emit('error', {statusCode: 412, message: 'Bid too low'});
					} else if (Date.now() > Date.parse(auction.endDate)) {
						context.emit('error', {statusCode: 412, message: 'Bid too late'});
					} else {
						AuctionBid.create({
							auctionId: auctionId,
							customerId: customerId,
							price: price}, (err, newBid) => {
								if (err) {
									context.emit('error', {statusCode: 500, message: err});
								} else {
									console.log(customerId);
									Auction.updateOne({_id: auctionId}, {"auctionWinner": customerId}, (err, res) => {
										if (err) {
											context.emit('error', {statusCode: 500, message: err});
										} else if(!res) {
											context.emit('error', {statusCode: 400, "Customer not found"});
										} else {
											console.log("no error");
										}
									});
									context.emit(context.events.PLACE_NEW_BID, newBid);
								}
						});
					}
				});
			}
		});
	};
};

module.exports = AuctionService;
