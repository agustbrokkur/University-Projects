// Here the web service should be setup and routes declared

const express = require("express");
const bodyParser = require("body-parser");

const artService = require("./services/artService");
const artistService = require("./services/artistService");
const auctionService = require("./services/auctionService");
const customerService = require("./services/customerService");

const port = 3000;

const app = express();

app.use(bodyParser.json());

// This applies for all routes:
// • If a resource is not found, the web service should always return a status code 404
// • In POST requests which include ids from another resource, the ids should be validated by
//   checking if they exist. If they don’t exist the web service should return a status code 400
// • If an error occurs on the database level, the web service should return a status code 500

// ######### ARTS #########
// /api/arts [GET] - Gets all arts

app.get("/api/arts", (req, res) => {
    const artEmitter = new artService();
    artEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    artEmitter.on(artEmitter.events.GET_ALL_ARTS, data => res.status(200).send(data));
    artEmitter.getAllArts();
});

//• /api/arts/:id [GET] - Gets an art by id
app.get("/api/arts/:id", (req, res) => {
    const {id} = req.params;
    const artEmitter = new artService();
    artEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    artEmitter.on(artEmitter.events.GET_ART_BY_ID, data => res.status(200).send(data));
    artEmitter.getArtById(id);
});

//• /api/arts [POST] - Creates a new art (see how model should look like in Model section)
app.post("/api/arts", (req, res) => {
    const {body} = req;
    const artEmitter = new artService();
    artEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    artEmitter.on(artEmitter.events.CREATE_ART, data => res.status(200).send(data));
    artEmitter.createArt(body);
});


// ######### ARTISTS #########

//• /api/artists [GET] - Gets all artists
app.get("/api/artists", (req, res) => {
	const artistEmitter = new artistService();
    artistEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    artistEmitter.on(artistEmitter.events.GET_ALL_ARTISTS, artists => res.status(200).send(artists));
    artistEmitter.getAllArtists();
});

//• /api/artists/:id [GET] - Gets an artist by id
app.get("/api/artists/:id", (req, res) => {
	const artistEmitter = new artistService();
    const {id} = req.params;
    artistEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    artistEmitter.on(artistEmitter.events.GET_ARTIST_BY_ID, artist => res.status(200).send(artist));
    artistEmitter.getArtistById(id);
});

//• /api/artists [POST] - Creates a new artist (see how model should look like in Model section)
app.post("/api/artists", (req, res) => {
	const artistEmitter = new artistService();
    const newArtist = req.body;
    artistEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    artistEmitter.on(artistEmitter.events.CREATE_ARTIST, artist => res.status(200).send(artist));
    artistEmitter.createArtist(newArtist);
});

// ######### CUSTOMERS #########

//• /api/customers [GET] - Gets all customers
app.get("/api/customers", (req, res) => {
	const customerEmitter = new customerService();
    customerEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    customerEmitter.on(customerEmitter.events.GET_ALL_CUSTOMERS, customers => res.status(200).send(customers));
    customerEmitter.getAllCustomers();
});

//• /api/customers/:id [GET] - Gets a customer by id
app.get("/api/customers/:id", (req, res) => {
	const customerEmitter = new customerService();
    const {id} = req.params;
    customerEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    customerEmitter.on(customerEmitter.events.GET_CUSTOMER_BY_ID, customer => res.status(200).send(customer));
    customerEmitter.getCustomerById(id);
});

//• /api/customers [POST] - Creates a new customer (see how model should look like in Model section) 
app.post("/api/customers", (req, res) => {
	const customerEmitter = new customerService();
    const newCustomer = req.body;
    customerEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    customerEmitter.on(customerEmitter.events.CREATE_CUSTOMER, customer => res.status(200).send(customer));
    customerEmitter.createCustomer(newCustomer);

});

//• /api/customers/:id/auction-bids [GET] - Gets all auction bids associated with a customer
app.get("/api/customers/:id/auction-bids", (req, res) => {
	const customerEmitter = new customerService();
    const {id} = req.params;
    customerEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    customerEmitter.on(customerEmitter.events.GET_CUSTOMER_AUCTION_BIDS, customer => res.status(200).send(customer));
    customerEmitter.getCustomerAuctionBids(id);

});

// ######### AUCTIONS #########

//• /api/auctions [GET] - Gets all auctions
app.get("/api/auctions", (req, res) => {
  // 400, 404, 500
	const auctionEmitter = new auctionService();
    auctionEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    auctionEmitter.on(auctionEmitter.events.GET_ALL_AUCTIONS, auctions => res.status(200).send(auctions));
    auctionEmitter.getAllAuctions();
});

//• /api/auctions/:id [GET] - Gets an auction by id
app.get("/api/auctions/:id", (req, res) => {
  // 400, 404, 500
	const auctionEmitter = new auctionService();
    const {id} = req.params;
    auctionEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    auctionEmitter.on(auctionEmitter.events.GET_AUCTION_BY_ID, auction => res.status(200).send(auction));
    auctionEmitter.getAuctionById(id);
});

//• /api/auctions/:id/winner [GET] - Gets the winner of the auction.
//If the auction is not ﬁnished the web service should return a status code 409 (Conﬂict),
//otherwise it should return the customer which holds the highest bid.
//If the auction had no bids, it should return a status code 200 (OK) with the message: ‘This auction had no bids.’. 
app.get("/api/auctions/:id/winner", (req, res) => {
  // 400, 404, 500
	const auctionEmitter = new auctionService();
    const {id} = req.params;
    auctionEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    auctionEmitter.on('no bids', msg => res.status(msg.statusCode).send(msg.message));
    auctionEmitter.on(auctionEmitter.events.GET_AUCTION_WINNER, customer => res.status(200).send(customer));
    auctionEmitter.getAuctionWinner(id);
});

//• /api/auctions [POST] - Create a new auction (see how model should look like in Model section).
//The art id provided within the body must be a valid art id with its property isAuctionItem set to true.
//If the isAuctionItem is set to false, the web service should return a status code 412 (Precondition failed).
app.post("/api/auctions", (req, res) => {
    const auctionEmitter = new auctionService();

    auctionEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    auctionEmitter.on(auctionEmitter.events.CREATE_AUCTION, data => res.status(200).send(data));
    auctionEmitter.createAuction(req.body);
});

//• /api/auctions/:id/bids [GET] - Gets all auction bids associated with an auction
app.get("/api/auctions/:id/bids", (req, res) => {
  // 400, 404, 500
	const auctionEmitter = new auctionService();
    const {id} = req.params;
    auctionEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    auctionEmitter.on(auctionEmitter.events.GET_AUCTION_BIDS_WITHIN_AUCTION, bids => res.status(200).send(bids));
    auctionEmitter.getAuctionBidsWithinAuction(id);
});

//• /api/auctions/:id/bids [POST] - Creates a new auction bid (see how model should look like in Model section).
//Auction bids must be higher than the minimum price and must also be higher than the current highest bid.
//If the auction bid price is lower than the minimum price or current highest bid,
//the web service should return a status code 412 (Precondition failed).
//If the auction has already passed its end date, the web service should return a status code 403 (Forbidden).
//As a side-eﬀect the auctionWinner property in the Auction schema should be updated to the latest highest bidder.
app.post("/api/auctions/:id/bids", (req, res) => {
    const auctionEmitter = new auctionService();
    //const {price, customerId} = req.body;
    const newBid = req.body;
    const {id} = req.params;
    auctionEmitter.on('error', err => res.status(err.statusCode).send(err.message));
    auctionEmitter.on(auctionEmitter.events.PLACE_NEW_BID, data => res.status(200).send(data));
    auctionEmitter.placeNewBid(id, newBid.customerId, newBid.price);
});

app.listen(port, () => {
    console.log("Server is listening on port " + port);
});
